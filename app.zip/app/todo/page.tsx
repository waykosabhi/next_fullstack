"use client";
import React from "react";

const page = () => {
  const handleResponse = (e: FormData) => {
    const task = e.get("task");
    const desc = e.get("desc");
  };
  return (
    <>
      <form action={handleResponse}>
        <input type="text" name="task" />
        <input type="text" name="desc" />
        <button>Add Todo</button>
      </form>
    </>
  );
};

export default page;
