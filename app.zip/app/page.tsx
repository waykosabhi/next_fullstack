
import Link from 'next/link'
import React from 'react'

const page = () => {
  return (
    <>
    <Link href="/todo">Todo</Link>
    
    </>
  )
}

export default page